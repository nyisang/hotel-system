<div class="navbar navbar-fixed-top bs-docs-nav" role="banner">
	<div class="conjtainer">
      <!-- Menu button for smallar screens -->
      <div class="navbar-header">
		  <button class="navbar-toggle btn-navbar" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
			
		  </button>
		  <!-- Site name for smallar screens -->
		  
		</div>
		<!-- Navigation starts -->
      <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">  
	  <ul class="nav navbar-nav">  
          <!-- Upload to server link. Class "dropdown-big" creates big dropdown 
      

          <!-- Upload to server link. Class "dropdown-big" creates big dropdown -->
         
            <!-- Dropdown -->

          </li>

        </ul>

        <!-- Search form -->
       
       
      </nav> 

    </div>
	</div>
	